import os
import cv2

#Estamos creando una varibale tipo lista, que nos va a mostrar una lista de todas las imagenes
path = "Images"

images = []


for file in os.listdir(path):
    #separar el nombre y la extencion de un archivo
    name, ext = os.path.splitext(file)

    if ext in ['.gif', '.png', '.jpg', '.jpeg','.jfif']:
        file_name = path+"/"+file

        print(file_name)
    #append es para agregar   
        images.append(file_name)
        
print(len(images))
count = len(images)

#Estamos pideiendole a la computadora que nos de el tamaño de las iamgenes me salio (1280, 720)

frame = cv2.imread(images[0])
height, width, channels = frame.shape
size = (width, height)
print(size)

#out es una variable
out=cv2.VideoWriter('project.mp4', cv2.VideoWriter_fourcc(*'DIVX'), 5, size)

for i in range(count-1,0,-1):
    frame = cv2.imread(images[i])
    out.write(frame)

    out.release()
    print("Listo")