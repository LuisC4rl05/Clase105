# PROC105-V1-actividad-alumno1
Python. OpenCV. Plantilla del alumno.  
  
Lesson plan.  

### Texto en inglés: PRO-C105-Student-Boilerplate
